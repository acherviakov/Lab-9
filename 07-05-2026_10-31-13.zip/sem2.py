'''
### Вариант 3. Класс «Товар»
**Класс:** `Product`  
**Поля:** `name` (название), `price` (цена).  
**Задание:**  
1. Перегрузите операторы сравнения так, чтобы товары сравнивались по цене (чем дешевле, тем «меньше»).  
2. Создайте список товаров.  
3. Отсортируйте товары от самого дешёвого к самому дорогому.  
4. Определите, есть ли в списке товары с одинаковой ценой, используя оператор `==` (или `in` с предварительной сортировкой).
'''
def bubble_sort(array):
    no_swaps = False
    times_repeated = False
    in_array_same_found = False
    while( not no_swaps and times_repeated < len(array) - 1):
        no_swaps = True
        array, same_found, no_swaps = one_cycle_of_bubble_sort(array)
        if(not in_array_same_found):
            in_array_same_found = same_found
        times_repeated += 1
    return array, in_array_same_found
    

def one_cycle_of_bubble_sort(array):
    same_found = False
    no_swaps = True
    for i in range(1, len(array)):
        if array[i-1] > array[i]:
            array[i-1], array[i] = array[i], array[i-1]
            no_swaps = False
        if array[i-1] == array[i]:
            same_found = True
    return (array, same_found, no_swaps)

class Product:
    def __init__(self, name, price):
        self.__name = name
        self.__price = price
    @property
    def name(self):
        return self.__name
    @property
    def price(self):
        return self.__price
    @price.setter
    def price(self, name):
        self.__name = name
    @name.setter
    def name(self, price):
        self.__price = price
    def __str__(self):
        return f"товар {self.name} с ценой {self.price}"
    def __lt__(self, other):
        return self.__price < other.__price
    def __gt__(self, other):
        return self.__price > other.__price
    def __le__(self, other):
        return self.__price <= other.__price
    def __ge__(self, other):
        return self.__price >= other.__price
    def __eq__(self, other):
        return self.__price == other.__price
    def __ne__(self, other):
        return self.__price != other.__price
    
my_list = [Product("Cheese", 150),  Product("Milk", 170), Product("Beef", 300), Product("Strawberry", 350), Product("Bread", 150)]

my_lis, same_found = bubble_sort(my_list)

for el in my_list:
    print(el)
print( "одинаковые элементы найдены" if same_found else "одинаковые элементы не найдены")