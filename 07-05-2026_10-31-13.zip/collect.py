from planet import *
class Collect:
    def __init__(self, array):
        self.array = array
    def __str__(self):
        return str(self.array)
    def run_query(self, data):
        data = data.split()
        if(data[0] == "create"):
            array = self.array + [Planet.from_string(data[1])]
            self.array = array
        elif(data[0] == "delete"):
            del self.array[int(data[1]) - 1]
        elif(data[0] == "print"):
           print(self.array)
        elif(data[0] == "save"):
           self.write_in_db(self)
        elif(data[0] == "read"):
           self.read_from_db(self)
        else:
            print("неправильный ввод")
    def write_in_db(self):
        with open("db.txt", "w") as database:
            for planet in self.array:
                print(planet, file=database)
    def read_from_db(self):
        with open("db.txt", "r") as database:
            self.array = []
            for line in database:
                current_line = line.strip("\n")
                self.array.append(Planet.from_string(current_line))