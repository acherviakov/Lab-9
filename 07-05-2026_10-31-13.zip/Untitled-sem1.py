class Ticket:
 
    def __init__(self, price, name, surname, seat, flight_number, departure_time):
        self.price = price
        self.name = name
        self.surname = surname
        self.seat = seat
        self.flight_number = flight_number
        self.departure_time = departure_time
    @staticmethod
    def has_digits(word):
        digits = "1234567890"
        for symbol in word:
            if symbol in digits:
                return False
        return True
    @staticmethod
    def are_all_digits(word):
        digits = "1234567890"
        for symbol in word:
            if symbol not in digits:
                return False
        return True

    @property
    def price(self):
        return self.__price
    @property
    def name(self):
        return self.__name
    @property
    def surname(self):
        return self.__surname
    @property
    def flight_number(self):
        return self.flight_number
    @property
    def departure_time(self):
        return self.departure_time
    @property
    def seat(self):
        return self.__seat
    @price.setter
    def price(self, price):
        if price < 0:
            raise ValueError("цена должна быть неотрицательной")
        else:
            self.__price = price
    @name.setter
    def name(self, name):
        if len(name) == 0:
            raise ValueError("имя не должно быть пустым")
        elif Ticket.has_digits(name):
            raise ValueError("имя не должно содержать цифр")
        else:
            self.__name = name
    @surname.setter
    def surname(self, surname):
        if len(surname) == 0:
            raise ValueError("фамилия не должна быть пустой")
        elif Ticket.has_digits(surname):
            raise ValueError("фамилия не должна содержать цифр")
        else:
            self.__surname = surname
    @flight_number.setter
    def flight_number(self, flight_number):
        self._flight_number = flight_number
    @departure_time.setter
    def departure_time(self, departure_time):
        time = departure_time.split(":")
        if len(time) != 2:
            raise ValueError("должно быть два числа, разделенных двоеточием")
        hours = time[0]
        minutes = time[1]
        if not Ticket.are_all_digits(hours):
            raise ValueError("количесво часов не является числом")
        if not Ticket.are_all_digits(minutes):
            raise ValueError("количесво минут не является числом")
        if not(0 <= int(hours) <24):
            raise("кол-во часов должно быть между 0 и 23")
        if not(0 <= int(minutes) <60):
            raise("кол-во минут должно быть между 0 и 59")
        self._departure_time = departure_time
    @seat.setter
    def seat(self, seat):
        letters_array = [chr(i + ord("A")) for i in range(26)]
        if len(seat) == 0:
            raise ValueError("место не должно быть пустым")
        if seat[0] in letters_array and Ticket.are_all_digits(seat[1:]):
            self.__seat = seat
        else:
            raise ValueError("неверный формат")
        
    def from_string(self, string):
        array = string.split()
        self._init_(self, array[0], array[1], array[2], array[3], array[4], array[5])
