def sqrt(x):
    return x**0.5
def roots(x):
    rt = False
    final = ""
    digits = "1234567890"
    for el in (x + " "):
        if (rt == True and el not in digits):
            rt = False
            final = final + "}"        
        final = final + el
        if(el == "v"):
            rt = True
    return final.strip()
def tolatex(x):
    x = x.replace("u", "\\cup")
    x = x.replace("[", "\\[")
    x = x.replace("]", "\\]")
    x = x.replace("{", "\\{")
    x = x.replace("}", "\\}")
    if x == "":
        return "\\emptyset"
    if "/" in x:
        x = x.replace("/", "}{")
        x = "\\frac{"+x+"}"
    x = roots(x)
    x = x.replace("v", " \\sqrt{")

    return x
    
def calc(x):
    if x == "inf":
        return "inf"
    if "/" in x:
        x = x.replace("/", ")/(")
        x = "("+x+")"
    x = roots(x)
    x = x.replace("}", ")")
    x = x.replace("v", "*sqrt(")
    x = x.replace(" ", "")
    if x[0] == "*":
        x = x[1:]
    x = x.replace("+*", "+")
    x = x.replace("-*", "-")
    x = x.replace("(*", "(")
    return eval(x)
    
def equal(a, b):
    if a == "inf" and b == "inf":
        return True
    elif a == "inf" or b == "inf":
        return False
    return abs(calc(a)-calc(b)) < 0.0000001

def arrequal(a, b):
    for i in range(len(a)):
        if not equal(a[i], b[i]):
            return False
        return True

def compare(corr, found, type):
    corr = corr.replace(" ", "")
    found = found.replace(" ", "")
    corr = corr.replace(",", ".")
    found = found.replace(",", ".")
    try:
        if type == "n":
            if equal(corr,found):
                return 1
            else:
                return 0
        elif type == "s":
            corr = corr.split(";")
            found = found.split(";")
            corr.sort()
            found.sort()
            if len(corr) != len(found):
                return 0
            else:
                for i in range(len(corr)):
                    if not equal(corr[i], found[i]):
                        return 0
                return 1
        elif type == "i":
            found.replace("}u{", ";")
            corr = corr.split("u")
            found = found.split("u")
            if len(corr) != len(found):
                return 0
            for i in range(len(corr)):
                if corr[i][0] != found[i][0]:
                    return 0
                if corr[i][-1] != found[i][-1]:
                    return 0
                corr_n = (corr[i][1:len(corr[i])-1]).split(";")
                found_n = (found[i][1:len(corr[i])-1]).split(";")
                if not arrequal(corr_n, found_n):
                    return 0
        return 1

            
    except Exception as e:
        return 2
'''
n = int(input())
types = []
corrs = []
founds = []

for i in range(n):
    inp = input().split()
    types.append(inp[0])
    corrs.append(inp[1])
for i in range(n):
    founds.append(input())
for i in range(n):
    print(tolatex(corrs[i], founds[i], types[i] ))
'''
print(tolatex(input()))