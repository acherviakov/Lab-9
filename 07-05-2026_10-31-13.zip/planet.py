class Planet:
    counter = 0
    def __init__(self, radius, mass, name, distance_from_sun, type):
        self.radius_in_km = radius
        self.mass_in_kg = mass
        self.name = name
        self.distance_from_sun_in_million_km = distance_from_sun
        self.type = type
        Planet.counter += 1
        print("Cоздание ID %s"%(self.counter))

    def __copy__(self):
        return Planet(self.raduis_in_km, self.mass_in_kg, self.name, self.distance_from_sun_in_million_kg, self.type)
    
    def __delitem__(self):
        print("Удаление ID %s"%(self.counter))

    def __lt__(self, other):
        return self.distance_from_sun_in_million_km < other.distance_from_sun_in_million_km
    
    def __eq__(self, other):
        return self.name == other.name
    
    def __gt__(self, other):
        return self.name > other.name
    def __str__(self):
        return f"{self.radius_in_km};{self.mass_in_kg};{self.name};{self.distance_from_sun_in_million_km};{self.type}"
    @property
    def radius_in_km(self):
        return self.__radius_in_kg
    @property
    def mass_in_kg(self):
        return self.__radius_in_km
    @property
    def name(self):
        return self.__name
    @property
    def distance_from_sun_in_million_km(self):
        return self.__distance_from_sun_in_million_km
    @property
    def type(self):
        return self.__type
    
    @radius_in_km.setter
    def radius_in_km(self, radius_in_km):
        if radius_in_km > 0:
            self.__radius_in_km = radius_in_km
    
    @mass_in_kg.setter
    def mass_in_kg(self, mass_in_kg):
        if mass_in_kg > 0:
            self.__mass_in_kg = mass_in_kg
    @distance_from_sun_in_million_km.setter
    def distance_from_sun_in_million_km(self, distance_from_sun_in_million_km):
        if distance_from_sun_in_million_km > 0:
            self.__distance_from_sun_in_million_km = distance_from_sun_in_million_km
    @type.setter
    def type(self, type):
        self.__type = type

    @name.setter
    def name(self, name):
        self.__name = name
    @staticmethod
    def from_string(string):
        data = string.split(";")
        return Planet(int(data[0]), int(data[1]), data[2], int(data[3]), data[4])


    