def dif(a, b):
    ares = a[0]*60 + a[1]
    bres = b[0]*60 + b[1]
    return (ares - bres)%1440


pasgr = list(map(int, input().split()))
n = int(input())
exist = False
current_min = [0,0]
amount = 1
for i in range(n):
    if not exist:
        current_min = list(map(int, input().split()))
        exist = True
    else:
        inp = list(map(int, input().split()))
        if dif(current_min, pasgr) > dif(inp, pasgr):
            amount = 1
            current_min = inp
        elif dif(current_min, pasgr) == dif(inp, pasgr):
            amount += 1
print(current_min[0], current_min[1])
if amount == 1:
    print("НЕТ")
else:
    print(amount, "ДА")