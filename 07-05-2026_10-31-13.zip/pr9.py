def ok(x):
    return x % 69 == 52 or x % 69 == 67

from random import *
n = int(input())
summa = 0
sq_summa = 0
prs = []
sqprs = []
prs.append(0)
sqprs.append(0)
for i in range(n):
    inp = int(input())
    summa += inp
    sq_summa += inp**2
    prs.append(summa)
    sqprs.append(sq_summa)
cur = [10000*n, 0]
for i in range(n+1):
    for j in range(i, n+1):
        if ok(sqprs[j]-sqprs[i]):
            cur = min(cur, [prs[j]-prs[i], -(j-i)])
print(-cur[1])